import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs, limit, onSnapshot,
  orderBy, query, serverTimestamp, setDoc, updateDoc, where, writeBatch
} from "firebase/firestore";
import {
  deleteObject, getDownloadURL, ref, uploadBytes
} from "firebase/storage";
import { auth, db, storage, ADMIN_EMAILS } from "./firebase";
import {
  Bell, Camera, Check, CheckCheck, ChevronLeft, Heart, Image as ImageIcon,
  LogOut, MessageCircle, MoreHorizontal, Plus, Search, Send, Shield,
  Trash2, UserPlus, Users, X
} from "lucide-react";
import "./styles.css";

const uid = () => auth.currentUser?.uid;
const nowMs = () => Date.now();
const avatar = (u) => u?.photoURL || `https://api.dicebear.com/9.x/initials/svg?seed=${encodeURIComponent(u?.username || "User")}`;

async function uploadFile(file, path) {
  const r = ref(storage, path);
  await uploadBytes(r, file);
  return getDownloadURL(r);
}

async function ensureProfile(user, username) {
  const refDoc = doc(db, "users", user.uid);
  const snap = await getDoc(refDoc);
  if (!snap.exists()) {
    await setDoc(refDoc, {
      uid: user.uid,
      username: username || user.email.split("@")[0],
      usernameLower: (username || user.email.split("@")[0]).toLowerCase(),
      email: user.email,
      bio: "",
      photoURL: user.photoURL || "",
      isPrivate: false,
      followersCount: 0,
      followingCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }
}

function App() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [screen, setScreen] = useState("home");
  const [selectedChat, setSelectedChat] = useState(null);
  const [selectedStory, setSelectedStory] = useState(null);
  const [authMode, setAuthMode] = useState("login");
  const [loading, setLoading] = useState(true);

  useEffect(() => onAuthStateChanged(auth, async u => {
    setUser(u);
    if (u) {
      await ensureProfile(u);
      const s = await getDoc(doc(db, "users", u.uid));
      setProfile(s.data());
    } else setProfile(null);
    setLoading(false);
  }), []);

  if (loading) return <div className="center"><div className="spinner"/></div>;
  if (!user) return <Auth onDone={() => {}} mode={authMode} setMode={setAuthMode}/>;

  const isAdmin = ADMIN_EMAILS.includes((user.email || "").toLowerCase());

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand" onClick={() => setScreen("home")}>Private<span>Chat</span></div>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setScreen("search")}><Search size={20}/></button>
          <button className="icon-btn" onClick={() => setScreen("notifications")}><Bell size={20}/></button>
        </div>
      </header>

      <main className="main">
        {screen === "home" && <Home profile={profile} onStory={setSelectedStory} />}
        {screen === "search" && <SearchUsers onOpen={u => { setScreen("profile"); window.__pcProfile=u; }} />}
        {screen === "chats" && <Chats onOpen={c => {setSelectedChat(c); setScreen("chat");}} />}
        {screen === "chat" && <Chat chat={selectedChat} onBack={() => setScreen("chats")} />}
        {screen === "create" && <CreateStory onDone={() => setScreen("home")} />}
        {screen === "notifications" && <Notifications />}
        {screen === "profile" && <ProfilePage userId={window.__pcProfile?.uid || uid()} current={profile} />}
        {screen === "admin" && isAdmin && <Admin />}
      </main>

      <nav className="bottom-nav">
        <Nav active={screen} id="home" label="Home" onClick={setScreen}/>
        <Nav active={screen} id="chats" label="Chats" icon={<MessageCircle size={21}/>} onClick={setScreen}/>
        <button className="create-btn" onClick={() => setScreen("create")}><Plus size={24}/></button>
        <Nav active={screen} id="notifications" label="Alerts" icon={<Bell size={21}/>} onClick={setScreen}/>
        <Nav active={screen} id="profile" label="Profile" icon={<Users size={21}/>} onClick={setScreen}/>
      </nav>

      {selectedStory && <StoryViewer story={selectedStory} onClose={() => setSelectedStory(null)}/>}
    </div>
  );
}

function Nav({active,id,label,onClick,icon}) {
  const icons = {home:"⌂", chats:"", notifications:"", profile:""};
  return <button className={`nav-item ${active===id?"active":""}`} onClick={() => onClick(id)}>
    {icon || <span className="home-icon">{icons[id]}</span>}<small>{label}</small>
  </button>
}

function Auth({mode,setMode}) {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [username,setUsername]=useState(""); const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
  const submit=async e=>{
    e.preventDefault(); setBusy(true); setError("");
    try {
      if(mode==="login") await signInWithEmailAndPassword(auth,email,password);
      else {
        if(username.trim().length<3) throw new Error("Username must be at least 3 characters.");
        const cred=await createUserWithEmailAndPassword(auth,email,password);
        await updateProfile(cred.user,{displayName:username.trim()});
        await ensureProfile(cred.user,username.trim());
      }
    } catch(err){ setError(err.message.replace("Firebase: ","")); }
    finally{setBusy(false);}
  };
  return <div className="auth-page">
    <div className="auth-card">
      <div className="logo-mark">PC</div>
      <h1>PrivateChat</h1><p className="muted">Private conversations. Simple sharing.</p>
      <form onSubmit={submit}>
        {mode==="signup" && <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" required/>}
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" required/>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" minLength="6" required/>
        {error && <div className="error">{error}</div>}
        <button className="primary" disabled={busy}>{busy?"Please wait…":mode==="login"?"Log in":"Create account"}</button>
      </form>
      <button className="link-btn" onClick={()=>setMode(mode==="login"?"signup":"login")}>
        {mode==="login"?"Create a new account":"Already have an account? Log in"}
      </button>
    </div>
  </div>
}

function Home({profile,onStory}) {
  const [stories,setStories]=useState([]); const [posts,setPosts]=useState([]);
  useEffect(()=>{
    const q=query(collection(db,"stories"),orderBy("createdAt","desc"),limit(100));
    return onSnapshot(q,s=>setStories(s.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.expiresAt?.toMillis?.()>nowMs() || x.expiresAt?.seconds*1000>nowMs())));
  },[]);
  return <div>
    <section className="section-head"><div><h2>Stories</h2><p className="muted">Share a moment for 24 hours</p></div><button className="soft-btn" onClick={()=>document.querySelector(".create-btn")?.click()}><Plus size={16}/> Story</button></section>
    <div className="stories">
      <div className="story-add" onClick={()=>document.querySelector(".create-btn")?.click()}><div className="story-ring add-ring"><Plus/></div><span>Your story</span></div>
      {stories.map(s=><div className="story-add" key={s.id} onClick={()=>onStory(s)}><img className="story-ring" src={s.mediaURL || avatar(s)} /><span>@{s.username}</span></div>)}
    </div>
    <div className="welcome-card"><div><span className="eyebrow">PRIVATE • REAL-TIME</span><h2>Stay connected without the noise.</h2><p>Message people you follow, share photos and videos, and keep your stories in one place.</p></div><MessageCircle size={38}/></div>
  </div>
}

function SearchUsers({onOpen}) {
  const [term,setTerm]=useState(""); const [users,setUsers]=useState([]);
  useEffect(()=>{ if(!term.trim()){setUsers([]);return;} const q=query(collection(db,"users"),where("usernameLower",">=",term.toLowerCase()),where("usernameLower","<=",term.toLowerCase()+"\uf8ff"),limit(20)); return onSnapshot(q,s=>setUsers(s.docs.map(d=>d.data()).filter(x=>x.uid!==uid()))); },[term]);
  return <div><h2>Search</h2><input className="search-input" placeholder="Search username…" value={term} onChange={e=>setTerm(e.target.value)}/>
  <div className="list">{users.map(u=><button className="user-row" key={u.uid} onClick={()=>onOpen(u)}><img src={avatar(u)}/><div><b>@{u.username}</b><span>{u.bio||"PrivateChat user"}</span></div><ChevronLeft className="rotate" size={18}/></button>)}</div></div>
}

function Chats({onOpen}) {
  const [chats,setChats]=useState([]);
  useEffect(()=>{
    const q=query(collection(db,"chats"),where("members","array-contains",uid()),orderBy("updatedAt","desc"));
    return onSnapshot(q,s=>setChats(s.docs.map(d=>({id:d.id,...d.data()}))));
  },[]);
  return <div><section className="section-head"><div><h2>Chats</h2><p className="muted">Your private conversations</p></div></section>
  <div className="list">{chats.length===0?<Empty title="No chats yet" text="Search for a user and start a conversation."/>:chats.map(c=><button className="user-row" key={c.id} onClick={()=>onOpen(c)}><img src={c.otherPhotoURL||avatar({username:c.otherUsername})}/><div><b>@{c.otherUsername}</b><span>{c.lastMessage||"Start chatting"}</span></div>{c.unread>0&&<i className="badge">{c.unread}</i>}</button>)}</div></div>
}

function Chat({chat,onBack}) {
  const [messages,setMessages]=useState([]); const [text,setText]=useState(""); const [file,setFile]=useState(null); const [sending,setSending]=useState(false);
  useEffect(()=>{ if(!chat?.id)return; const q=query(collection(db,"chats",chat.id,"messages"),orderBy("createdAt","asc"),limit(200)); return onSnapshot(q,s=>setMessages(s.docs.map(d=>({id:d.id,...d.data()})))); },[chat?.id]);
  const send=async e=>{
    e?.preventDefault(); if(!chat?.id || (!text.trim()&&!file))return; setSending(true);
    try {
      let mediaURL=""; let type="";
      if(file){ type=file.type.startsWith("video")?"video":"image"; mediaURL=await uploadFile(file,`chat-media/${uid()}/${Date.now()}-${file.name}`); }
      await addDoc(collection(db,"chats",chat.id,"messages"),{senderId:uid(),text:text.trim(),mediaURL,type,createdAt:serverTimestamp(),readBy:[uid()]});
      await updateDoc(doc(db,"chats",chat.id),{lastMessage:text.trim()||(type==="image"?"📷 Photo":"🎥 Video"),updatedAt:serverTimestamp(),lastSenderId:uid()});
      setText("");setFile(null);
    } finally {setSending(false);}
  };
  if(!chat)return <Empty title="Choose a chat" text="Open a conversation from Chats."/>;
  return <div className="chat-page">
    <div className="chat-head"><button className="icon-btn" onClick={onBack}><ChevronLeft/></button><img src={chat.otherPhotoURL||avatar({username:chat.otherUsername})}/><div><b>@{chat.otherUsername}</b><span>Private chat</span></div></div>
    <div className="messages">{messages.map(m=><div className={`bubble-wrap ${m.senderId===uid()?"mine":""}`} key={m.id}><div className="bubble">
      {m.mediaURL && (m.type==="video"?<video src={m.mediaURL} controls/>:<img src={m.mediaURL}/>)}
      {m.text&&<div>{m.text}</div>}<small>{m.createdAt?.toDate?.().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})||""} {m.senderId===uid()&&<CheckCheck size={13}/>}</small>
    </div></div>)}</div>
    <form className="composer" onSubmit={send}><label className="icon-btn"><ImageIcon/><input type="file" accept="image/*,video/*" hidden onChange={e=>setFile(e.target.files?.[0]||null)}/></label><input value={text} onChange={e=>setText(e.target.value)} placeholder={file?file.name:"Write a message…"}/><button className="send-btn" disabled={sending}><Send size={18}/></button></form>
  </div>
}

function CreateStory({onDone}) {
  const [file,setFile]=useState(null); const [caption,setCaption]=useState(""); const [busy,setBusy]=useState(false);
  const submit=async e=>{e.preventDefault(); if(!file)return; setBusy(true); try{const me=(await getDoc(doc(db,"users",uid()))).data(); const mediaURL=await uploadFile(file,`stories/${uid()}/${Date.now()}-${file.name}`); await addDoc(collection(db,"stories"),{uid:uid(),username:me.username,photoURL:me.photoURL||"",mediaURL,caption,createdAt:serverTimestamp(),expiresAt:new Date(Date.now()+86400000),type:file.type.startsWith("video")?"video":"image",likes:[],views:[],replyCount:0}); onDone();}finally{setBusy(false)}};
  return <div><button className="back-link" onClick={onDone}><ChevronLeft/> Back</button><h2>Create Story</h2><form className="card form-card" onSubmit={submit}><label className="upload-box"><Camera size={32}/><b>{file?file.name:"Choose photo or video"}</b><span>Story expires after 24 hours</span><input type="file" accept="image/*,video/*" hidden onChange={e=>setFile(e.target.files?.[0]||null)} required/></label><input value={caption} onChange={e=>setCaption(e.target.value)} placeholder="Add a caption…"/><button className="primary" disabled={busy}>{busy?"Uploading…":"Post story"}</button></form></div>
}

function StoryViewer({story,onClose}) {
  const [liked,setLiked]=useState(story.likes?.includes(uid())); const [reply,setReply]=useState("");
  useEffect(()=>{(async()=>{const r=doc(db,"stories",story.id);const s=await getDoc(r);const d=s.data()||{};if(!(d.views||[]).includes(uid()))await updateDoc(r,{views:[...(d.views||[]),uid()]});})();},[story.id]);
  const like=async()=>{const r=doc(db,"stories",story.id);const s=await getDoc(r);const d=s.data()||{};const arr=d.likes||[];const next=arr.includes(uid())?arr.filter(x=>x!==uid()):[...arr,uid()];await updateDoc(r,{likes:next});setLiked(next.includes(uid()));};
  const sendReply=async e=>{e.preventDefault();if(!reply.trim())return;await addDoc(collection(db,"stories",story.id,"replies"),{uid:uid(),text:reply.trim(),createdAt:serverTimestamp()});await updateDoc(doc(db,"stories",story.id),{replyCount:(story.replyCount||0)+1});setReply("");};
  return <div className="story-overlay"><button className="close-story" onClick={onClose}><X/></button><div className="story-card">{story.type==="video"?<video src={story.mediaURL} autoPlay controls/>:<img src={story.mediaURL}/>}<div className="story-info"><b>@{story.username}</b><span>{story.caption}</span><div className="story-actions"><button onClick={like} className={liked?"liked":""}><Heart fill={liked?"currentColor":"none"}/>{story.likes?.length||0}</button><span>{story.views?.length||0} views</span></div><form onSubmit={sendReply}><input value={reply} onChange={e=>setReply(e.target.value)} placeholder="Reply to story…"/><button><Send/></button></form></div></div></div>
}

function ProfilePage({userId:target,current}) {
  const [p,setP]=useState(null); const [following,setFollowing]=useState(false); const [highlights,setHighlights]=useState([]);
  useEffect(()=>{getDoc(doc(db,"users",target)).then(s=>setP(s.data())); const q=query(collection(db,"follows"),where("followerId","==",uid()),where("followingId","==",target),limit(1)); return onSnapshot(q,s=>setFollowing(!s.empty));},[target]);
  if(!p)return <Empty title="Loading…" text=""/>;
  const follow=async()=>{const id=`${uid()}_${target}`;if(following){await deleteDoc(doc(db,"follows",id));await updateDoc(doc(db,"users",target),{followersCount:Math.max(0,(p.followersCount||1)-1)});setFollowing(false)}else{await setDoc(doc(db,"follows",id),{followerId:uid(),followingId:target,createdAt:serverTimestamp()});await updateDoc(doc(db,"users",target),{followersCount:(p.followersCount||0)+1});await addDoc(collection(db,"notifications"),{to:target,from:uid(),type:"follow",createdAt:serverTimestamp(),read:false});setFollowing(true)}};
  return <div><div className="profile-card"><img className="profile-avatar" src={avatar(p)}/><h2>@{p.username}</h2><p>{p.bio||"No bio yet."}</p><div className="stats"><div><b>{p.followersCount||0}</b><span>Followers</span></div><div><b>{p.followingCount||0}</b><span>Following</span></div></div>{target!==uid()&&<button className="primary" onClick={follow}>{following?"Following":"Follow"}</button>}</div><Highlights userId={target}/></div>
}

function Highlights({userId:target}) {
  const [hs,setHs]=useState([]);
  useEffect(()=>{return onSnapshot(query(collection(db,"highlights"),where("uid","==",target),orderBy("createdAt","desc")),s=>setHs(s.docs.map(d=>({id:d.id,...d.data()}))));},[target]);
  return <div className="section"><h3>Highlights</h3><div className="highlight-row">{hs.map(h=><div className="highlight" key={h.id}><img src={h.coverURL||avatar({username:h.name})}/><span>{h.name}</span></div>)}{hs.length===0&&<span className="muted">No highlights yet.</span>}</div></div>
}

function Notifications() {
  const [items,setItems]=useState([]);
  useEffect(()=>{return onSnapshot(query(collection(db,"notifications"),where("to","==",uid()),orderBy("createdAt","desc"),limit(50)),s=>setItems(s.docs.map(d=>({id:d.id,...d.data()}))));},[]);
  return <div><h2>Notifications</h2><div className="list">{items.length===0?<Empty title="All caught up" text="New activity will appear here."/>:items.map(n=><div className="notification" key={n.id}><Bell size={18}/><span><b>{n.type==="follow"?"New follower":"Activity"}</b><br/>{n.type==="follow"?"Someone followed you.":"You have new activity."}</span></div>)}</div></div>
}

function Admin() {
  const [users,setUsers]=useState([]); const [reports,setReports]=useState([]);
  useEffect(()=>{const u=onSnapshot(query(collection(db,"users"),orderBy("createdAt","desc"),limit(100)),s=>setUsers(s.docs.map(d=>({id:d.id,...d.data()})))); const r=onSnapshot(query(collection(db,"reports"),orderBy("createdAt","desc"),limit(100)),s=>setReports(s.docs.map(d=>({id:d.id,...d.data()})))); return ()=>{u();r();}},[]);
  const suspend=async u=>updateDoc(doc(db,"users",u.uid),{suspended:!u.suspended});
  return <div><div className="admin-title"><div><span className="eyebrow">ADMIN</span><h2>Moderation</h2></div><Shield/></div><div className="admin-grid"><div className="metric"><span>Users</span><b>{users.length}</b></div><div className="metric"><span>Reports</span><b>{reports.length}</b></div></div><h3>Users</h3><div className="list">{users.map(u=><div className="user-row" key={u.uid}><img src={avatar(u)}/><div><b>@{u.username}</b><span>{u.email}</span></div><button className="soft-btn" onClick={()=>suspend(u)}>{u.suspended?"Unsuspend":"Suspend"}</button></div>)}</div><h3>Reports</h3><div className="list">{reports.length===0?<Empty title="No reports" text="Nothing to review."/>:reports.map(r=><div className="notification" key={r.id}><Shield size={18}/><span>{r.reason||"Report"}<small>{r.createdAt?.toDate?.().toLocaleString()||""}</small></span></div>)}</div></div>
}

function Empty({title,text}){return <div className="empty"><div className="empty-icon">✦</div><b>{title}</b><span>{text}</span></div>}

createRoot(document.getElementById("root")).render(<App/>);
