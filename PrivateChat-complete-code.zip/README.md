# PrivateChat — complete starter project

This package contains the web app source for PrivateChat:
- Email/password authentication
- User profiles
- Search/follow
- 1-to-1 chat with real-time Firestore messages
- Photo/video chat uploads
- Stories with 24-hour client-side expiry
- Story views and likes
- Story replies
- Highlights data/UI
- Notifications
- Block/report data foundations
- Admin dashboard foundations
- Firestore + Storage security rules
- Responsive light UI

## What you still must provide

A real Firebase project is required for authentication, database and file storage. No code can legally or technically invent your private Firebase credentials.

### 1. Create Firebase project
Create a Firebase project, enable:
- Authentication -> Email/Password
- Firestore Database
- Storage

### 2. Add web app
Copy the Firebase web configuration into `.env` using `.env.example`.

### 3. Admin
Replace `you@example.com` in `firestore.rules` with the email that should be the admin.
Also put the same email in `VITE_ADMIN_EMAILS`.

### 4. Install and run
```bash
npm install
npm run dev
```

For production:
```bash
npm run build
```

The output is the `dist` folder.

## Important production notes

This is a functional full-stack web-app foundation, but a real public launch should additionally use:
- Firebase App Check
- stricter production security rules after testing
- server-side scheduled cleanup for expired stories
- server-side/admin custom claims instead of email-based admin rules
- abuse/rate limiting
- file-size/type limits
- moderation and age/privacy policy appropriate to your audience
- proper legal/privacy pages

The UI does not pretend that those services exist when they have not been configured.
